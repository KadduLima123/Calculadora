﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculadora
{
    public partial class FrmCalculadora : Form
    {
        private decimal resultado = 0;
        private decimal Valor = 0;
        private string operacaoSelecionada = string.Empty;
        public FrmCalculadora()
        {
            InitializeComponent();
        }

        private void FrmCalculadora_Load(object sender, EventArgs e)
        {
            BtnZero.Text = "0";
            BtnUm.Text = "1";
            BtnDois.Text = "2";
            BtnTres.Text = "3";
            BtnQuatro.Text = "4";
            BtnCinco.Text = "5";
            BtnSeis.Text = "6";
            BtnSete.Text = "7";
            BtnOito.Text = "8";
            BtnNove.Text = "9";
            BtnAdicao.Text = "+";
            BtnSubtracao.Text = "-";
            BtnMultiplicacao.Text = "*";
            BtnDivisao.Text = "/";

        }
        private void BtnZero_Click(object sender, EventArgs e)
        {
            if (txtResultado.Text != "0")
            {
                txtResultado.Text += "0";
            }
        }
        private void BtnUm_Click(object sender, EventArgs e)
        {
            txtResultado.Text += "1";
        }
        private void BtnDois_Click(object sender, EventArgs e)
        {
            txtResultado.Text += "2";
        }
        private void BtnTres_Click(object sender, EventArgs e)
        {
            txtResultado.Text += "3";
        }
        private void BtnQuatro_Click(object sender, EventArgs e)
        {
            txtResultado.Text += "4";
        }
        private void BtnCinco_Click(object sender, EventArgs e)
        {
            txtResultado.Text += "5";
        }
        private void BtnSeis_Click(object sender, EventArgs e)
        {
            txtResultado.Text += "6";
        }
        private void BtnSete_Click(object sender, EventArgs e)
        {
            txtResultado.Text += "7";
        }
        private void BtnOito_Click(object sender, EventArgs e)
        {
            txtResultado.Text += "8";
        }
        private void BtnNove_Click(object sender, EventArgs e)
        {
            txtResultado.Text += "9";
        }
        private void BtnAdicao_Click(object sender, EventArgs e)
        {
            operacaoSelecionada = BtnAdicao.Text;
            Valor = Convert.ToDecimal(txtResultado.Text);
            txtResultado.Text = "";
            txtOperacao.Text = txtResultado.Text + " + ";
        }
        private void BtnSubtracao_Click(object sender, EventArgs e)
        {
            operacaoSelecionada = BtnSubtracao.Text;
            Valor = Convert.ToDecimal(txtResultado.Text);
            txtResultado.Text = "";
            txtOperacao.Text = txtResultado.Text + " - ";
        }
        private void BtnMultiplicacao_Click(object sender, EventArgs e)
        {
            operacaoSelecionada = BtnMultiplicacao.Text;
            Valor = Convert.ToDecimal(txtResultado.Text);
            txtResultado.Text = "";
            txtOperacao.Text = txtResultado.Text + " * ";
        }
        private void BtnDivisao_Click(object sender, EventArgs e)
        {
            operacaoSelecionada = BtnDivisao.Text;
            Valor = Convert.ToDecimal(txtResultado.Text);
            txtResultado.Text = "";
            txtOperacao.Text = txtResultado.Text + " / ";
        }
        private void BtnIgual_Click(object sender, EventArgs e)
        {
            switch (operacaoSelecionada)
            {
                case "+":
                    resultado = Valor + Convert.ToDecimal(txtResultado.Text);
                    break;
                case "-":
                    resultado = Valor - Convert.ToDecimal(txtResultado.Text);
                    break;
                case "*":
                    resultado = Valor * Convert.ToDecimal(txtResultado.Text);
                    break;
                case "/":
                    if (Convert.ToDecimal(txtResultado.Text) != 0)
                    {
                        resultado = Valor / Convert.ToDecimal(txtResultado.Text);
                    }
                    else
                    {
                        txtResultado.Text = "Divisão por zero não é permitida.";
                        return;
                    }
                    break;
            }
            txtResultado.Text = Convert.ToString(resultado);
            txtOperacao.Text = "=";
        }
        private void BtnVirgula_Click(object sender, EventArgs e)
        {
            if (!txtResultado.Text.Contains(","))
                txtResultado.Text += ",";
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            txtResultado.Text = "";
            txtOperacao.Text = "";
        }
    }
}