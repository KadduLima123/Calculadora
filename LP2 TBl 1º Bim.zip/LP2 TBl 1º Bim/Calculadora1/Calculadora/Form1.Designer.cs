﻿namespace Calculadora
{
    partial class FrmCalculadora
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnAdicao = new System.Windows.Forms.Button();
            this.BtnIgual = new System.Windows.Forms.Button();
            this.BtnZero = new System.Windows.Forms.Button();
            this.BtnVirgula = new System.Windows.Forms.Button();
            this.BtnSubtracao = new System.Windows.Forms.Button();
            this.BtnTres = new System.Windows.Forms.Button();
            this.BtnDois = new System.Windows.Forms.Button();
            this.BtnUm = new System.Windows.Forms.Button();
            this.BtnMultiplicacao = new System.Windows.Forms.Button();
            this.BtnSeis = new System.Windows.Forms.Button();
            this.BtnCinco = new System.Windows.Forms.Button();
            this.BtnQuatro = new System.Windows.Forms.Button();
            this.BtnDivisao = new System.Windows.Forms.Button();
            this.BtnNove = new System.Windows.Forms.Button();
            this.BtnOito = new System.Windows.Forms.Button();
            this.BtnSete = new System.Windows.Forms.Button();
            this.BtnLimpar = new System.Windows.Forms.Button();
            this.txtOperacao = new System.Windows.Forms.Label();
            this.txtResultado = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // BtnAdicao
            // 
            this.BtnAdicao.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnAdicao.Location = new System.Drawing.Point(177, 264);
            this.BtnAdicao.Name = "BtnAdicao";
            this.BtnAdicao.Size = new System.Drawing.Size(49, 48);
            this.BtnAdicao.TabIndex = 56;
            this.BtnAdicao.Text = "+";
            this.BtnAdicao.UseVisualStyleBackColor = true;
            this.BtnAdicao.Click += new System.EventHandler(this.BtnAdicao_Click);
            // 
            // BtnIgual
            // 
            this.BtnIgual.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnIgual.Location = new System.Drawing.Point(122, 264);
            this.BtnIgual.Name = "BtnIgual";
            this.BtnIgual.Size = new System.Drawing.Size(49, 48);
            this.BtnIgual.TabIndex = 55;
            this.BtnIgual.Text = "=";
            this.BtnIgual.UseVisualStyleBackColor = true;
            this.BtnIgual.Click += new System.EventHandler(this.BtnIgual_Click);
            // 
            // BtnZero
            // 
            this.BtnZero.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnZero.Location = new System.Drawing.Point(67, 264);
            this.BtnZero.Name = "BtnZero";
            this.BtnZero.Size = new System.Drawing.Size(49, 48);
            this.BtnZero.TabIndex = 54;
            this.BtnZero.Text = "0";
            this.BtnZero.UseVisualStyleBackColor = true;
            this.BtnZero.Click += new System.EventHandler(this.BtnZero_Click);
            // 
            // BtnVirgula
            // 
            this.BtnVirgula.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnVirgula.Location = new System.Drawing.Point(12, 264);
            this.BtnVirgula.Name = "BtnVirgula";
            this.BtnVirgula.Size = new System.Drawing.Size(49, 48);
            this.BtnVirgula.TabIndex = 53;
            this.BtnVirgula.Text = ",";
            this.BtnVirgula.UseVisualStyleBackColor = true;
            this.BtnVirgula.Click += new System.EventHandler(this.BtnVirgula_Click);
            // 
            // BtnSubtracao
            // 
            this.BtnSubtracao.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnSubtracao.Location = new System.Drawing.Point(177, 210);
            this.BtnSubtracao.Name = "BtnSubtracao";
            this.BtnSubtracao.Size = new System.Drawing.Size(49, 48);
            this.BtnSubtracao.TabIndex = 52;
            this.BtnSubtracao.Text = "-";
            this.BtnSubtracao.UseVisualStyleBackColor = true;
            this.BtnSubtracao.Click += new System.EventHandler(this.BtnSubtracao_Click);
            // 
            // BtnTres
            // 
            this.BtnTres.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnTres.Location = new System.Drawing.Point(122, 210);
            this.BtnTres.Name = "BtnTres";
            this.BtnTres.Size = new System.Drawing.Size(49, 48);
            this.BtnTres.TabIndex = 51;
            this.BtnTres.Text = "3";
            this.BtnTres.UseVisualStyleBackColor = true;
            this.BtnTres.Click += new System.EventHandler(this.BtnTres_Click);
            // 
            // BtnDois
            // 
            this.BtnDois.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnDois.Location = new System.Drawing.Point(67, 210);
            this.BtnDois.Name = "BtnDois";
            this.BtnDois.Size = new System.Drawing.Size(49, 48);
            this.BtnDois.TabIndex = 50;
            this.BtnDois.Text = "2";
            this.BtnDois.UseVisualStyleBackColor = true;
            this.BtnDois.Click += new System.EventHandler(this.BtnDois_Click);
            // 
            // BtnUm
            // 
            this.BtnUm.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnUm.Location = new System.Drawing.Point(12, 210);
            this.BtnUm.Name = "BtnUm";
            this.BtnUm.Size = new System.Drawing.Size(49, 48);
            this.BtnUm.TabIndex = 49;
            this.BtnUm.Text = "1";
            this.BtnUm.UseVisualStyleBackColor = true;
            this.BtnUm.Click += new System.EventHandler(this.BtnUm_Click);
            // 
            // BtnMultiplicacao
            // 
            this.BtnMultiplicacao.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnMultiplicacao.Location = new System.Drawing.Point(177, 156);
            this.BtnMultiplicacao.Name = "BtnMultiplicacao";
            this.BtnMultiplicacao.Size = new System.Drawing.Size(49, 48);
            this.BtnMultiplicacao.TabIndex = 48;
            this.BtnMultiplicacao.Text = "*";
            this.BtnMultiplicacao.UseVisualStyleBackColor = true;
            this.BtnMultiplicacao.Click += new System.EventHandler(this.BtnMultiplicacao_Click);
            // 
            // BtnSeis
            // 
            this.BtnSeis.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnSeis.Location = new System.Drawing.Point(122, 156);
            this.BtnSeis.Name = "BtnSeis";
            this.BtnSeis.Size = new System.Drawing.Size(49, 48);
            this.BtnSeis.TabIndex = 47;
            this.BtnSeis.Text = "6";
            this.BtnSeis.UseVisualStyleBackColor = true;
            this.BtnSeis.Click += new System.EventHandler(this.BtnSeis_Click);
            // 
            // BtnCinco
            // 
            this.BtnCinco.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnCinco.Location = new System.Drawing.Point(67, 156);
            this.BtnCinco.Name = "BtnCinco";
            this.BtnCinco.Size = new System.Drawing.Size(49, 48);
            this.BtnCinco.TabIndex = 46;
            this.BtnCinco.Text = "5";
            this.BtnCinco.UseVisualStyleBackColor = true;
            this.BtnCinco.Click += new System.EventHandler(this.BtnCinco_Click);
            // 
            // BtnQuatro
            // 
            this.BtnQuatro.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnQuatro.Location = new System.Drawing.Point(12, 156);
            this.BtnQuatro.Name = "BtnQuatro";
            this.BtnQuatro.Size = new System.Drawing.Size(49, 48);
            this.BtnQuatro.TabIndex = 43;
            this.BtnQuatro.Text = "4";
            this.BtnQuatro.UseVisualStyleBackColor = true;
            this.BtnQuatro.Click += new System.EventHandler(this.BtnQuatro_Click);
            // 
            // BtnDivisao
            // 
            this.BtnDivisao.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnDivisao.Location = new System.Drawing.Point(177, 102);
            this.BtnDivisao.Name = "BtnDivisao";
            this.BtnDivisao.Size = new System.Drawing.Size(49, 48);
            this.BtnDivisao.TabIndex = 45;
            this.BtnDivisao.Text = "/";
            this.BtnDivisao.UseVisualStyleBackColor = true;
            this.BtnDivisao.Click += new System.EventHandler(this.BtnDivisao_Click);
            // 
            // BtnNove
            // 
            this.BtnNove.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnNove.Location = new System.Drawing.Point(122, 102);
            this.BtnNove.Name = "BtnNove";
            this.BtnNove.Size = new System.Drawing.Size(49, 48);
            this.BtnNove.TabIndex = 44;
            this.BtnNove.Text = "9";
            this.BtnNove.UseVisualStyleBackColor = true;
            this.BtnNove.Click += new System.EventHandler(this.BtnNove_Click);
            // 
            // BtnOito
            // 
            this.BtnOito.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnOito.Location = new System.Drawing.Point(67, 102);
            this.BtnOito.Name = "BtnOito";
            this.BtnOito.Size = new System.Drawing.Size(49, 48);
            this.BtnOito.TabIndex = 42;
            this.BtnOito.Text = "8";
            this.BtnOito.UseVisualStyleBackColor = true;
            this.BtnOito.Click += new System.EventHandler(this.BtnOito_Click);
            // 
            // BtnSete
            // 
            this.BtnSete.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnSete.Location = new System.Drawing.Point(12, 102);
            this.BtnSete.Name = "BtnSete";
            this.BtnSete.Size = new System.Drawing.Size(49, 48);
            this.BtnSete.TabIndex = 41;
            this.BtnSete.Text = "7";
            this.BtnSete.UseVisualStyleBackColor = true;
            this.BtnSete.Click += new System.EventHandler(this.BtnSete_Click);
            // 
            // BtnLimpar
            // 
            this.BtnLimpar.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnLimpar.Location = new System.Drawing.Point(177, 48);
            this.BtnLimpar.Name = "BtnLimpar";
            this.BtnLimpar.Size = new System.Drawing.Size(49, 48);
            this.BtnLimpar.TabIndex = 40;
            this.BtnLimpar.Text = "C";
            this.BtnLimpar.UseVisualStyleBackColor = true;
            this.BtnLimpar.Click += new System.EventHandler(this.BtnLimpar_Click);
            // 
            // txtOperacao
            // 
            this.txtOperacao.AutoSize = true;
            this.txtOperacao.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.txtOperacao.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOperacao.Location = new System.Drawing.Point(13, 14);
            this.txtOperacao.Name = "txtOperacao";
            this.txtOperacao.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtOperacao.Size = new System.Drawing.Size(0, 25);
            this.txtOperacao.TabIndex = 39;
            this.txtOperacao.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtResultado
            // 
            this.txtResultado.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.txtResultado.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtResultado.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtResultado.Location = new System.Drawing.Point(12, 12);
            this.txtResultado.Multiline = true;
            this.txtResultado.Name = "txtResultado";
            this.txtResultado.Size = new System.Drawing.Size(214, 32);
            this.txtResultado.TabIndex = 38;
            this.txtResultado.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // FrmCalculadora
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(233, 326);
            this.Controls.Add(this.BtnAdicao);
            this.Controls.Add(this.BtnIgual);
            this.Controls.Add(this.BtnZero);
            this.Controls.Add(this.BtnVirgula);
            this.Controls.Add(this.BtnSubtracao);
            this.Controls.Add(this.BtnTres);
            this.Controls.Add(this.BtnDois);
            this.Controls.Add(this.BtnUm);
            this.Controls.Add(this.BtnMultiplicacao);
            this.Controls.Add(this.BtnSeis);
            this.Controls.Add(this.BtnCinco);
            this.Controls.Add(this.BtnQuatro);
            this.Controls.Add(this.BtnDivisao);
            this.Controls.Add(this.BtnNove);
            this.Controls.Add(this.BtnOito);
            this.Controls.Add(this.BtnSete);
            this.Controls.Add(this.BtnLimpar);
            this.Controls.Add(this.txtOperacao);
            this.Controls.Add(this.txtResultado);
            this.Name = "FrmCalculadora";
            this.Text = "Calculadora";
            this.Load += new System.EventHandler(this.FrmCalculadora_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnAdicao;
        private System.Windows.Forms.Button BtnIgual;
        private System.Windows.Forms.Button BtnZero;
        private System.Windows.Forms.Button BtnVirgula;
        private System.Windows.Forms.Button BtnSubtracao;
        private System.Windows.Forms.Button BtnTres;
        private System.Windows.Forms.Button BtnDois;
        private System.Windows.Forms.Button BtnUm;
        private System.Windows.Forms.Button BtnMultiplicacao;
        private System.Windows.Forms.Button BtnSeis;
        private System.Windows.Forms.Button BtnCinco;
        private System.Windows.Forms.Button BtnQuatro;
        private System.Windows.Forms.Button BtnDivisao;
        private System.Windows.Forms.Button BtnNove;
        private System.Windows.Forms.Button BtnOito;
        private System.Windows.Forms.Button BtnSete;
        private System.Windows.Forms.Button BtnLimpar;
        private System.Windows.Forms.Label txtOperacao;
        private System.Windows.Forms.TextBox txtResultado;
    }
}

